mkdir -p build
cd build
cmake ..
make


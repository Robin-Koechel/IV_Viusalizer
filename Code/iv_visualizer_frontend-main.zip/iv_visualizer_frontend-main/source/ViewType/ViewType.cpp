#include "ViewType.h"

// Constructor
ViewType::ViewType() {}

ViewType::~ViewType() {}

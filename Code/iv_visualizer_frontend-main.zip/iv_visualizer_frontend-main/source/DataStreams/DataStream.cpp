#include "DataStream.h"

DataStream::DataStream(){}
